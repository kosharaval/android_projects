package com.example.beerapp.interfaces;

public interface PunkResponse {

    void onFinish(String result);
}
