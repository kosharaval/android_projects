module battelship {
	requires java.desktop;
}