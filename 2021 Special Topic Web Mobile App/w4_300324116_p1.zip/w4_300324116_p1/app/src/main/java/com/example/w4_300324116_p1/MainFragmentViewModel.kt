package com.example.w4_300324116_p1

import androidx.lifecycle.ViewModel

class MainFragmentViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}