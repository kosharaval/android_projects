package com.example.w4_300324116_p1

import androidx.lifecycle.ViewModel

class ViewBalanceViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}