package com.example.mynavcompdemo1
const val NEW_NOTE_ID = 0