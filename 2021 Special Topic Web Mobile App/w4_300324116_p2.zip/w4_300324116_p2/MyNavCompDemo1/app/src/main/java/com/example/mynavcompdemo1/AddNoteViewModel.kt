package com.example.mynavcompdemo1

import androidx.lifecycle.ViewModel

class AddNoteViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}