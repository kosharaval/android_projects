package com.example.midterm_300324116

const val NEW_JOB_ID = 0
const val JOB_TEXT_KEY = "jobTextKey"
const val CURSOR_POSITION_KEY = "cursorPositionKey"
const val SELECTED_JOB_KEY = "selectedNotesKey"