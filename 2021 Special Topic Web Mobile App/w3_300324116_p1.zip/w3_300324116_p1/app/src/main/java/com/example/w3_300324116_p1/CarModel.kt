package com.example.w3_300324116_p1

data class CarModel(
    var item:String
)
