package com.example.finalexam_300324116

import androidx.lifecycle.ViewModel

class FragmentSearchAirbnb300324116ViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}