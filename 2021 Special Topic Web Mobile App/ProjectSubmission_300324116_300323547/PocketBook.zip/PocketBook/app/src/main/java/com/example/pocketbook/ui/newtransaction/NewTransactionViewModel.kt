package com.example.pocketbook.ui.newtransaction

import androidx.lifecycle.ViewModel

class NewTransactionViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}