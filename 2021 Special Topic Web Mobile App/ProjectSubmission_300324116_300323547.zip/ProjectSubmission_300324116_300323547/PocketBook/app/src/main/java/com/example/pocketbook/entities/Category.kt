package com.example.pocketbook.entities

data class Category(
    val category_name: String = "",
    val category_type: String = ""
)
