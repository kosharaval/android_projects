package com.example.mynavcompdemo1

const val NEW_NOTE_ID = 0
const val NOTE_TEXT_KEY = "noteTextKey"
const val CURSOR_POSITION_KEY = "cursorPositionKey"
const val SELECTED_NOTES_KEY = "selectedNotesKey"